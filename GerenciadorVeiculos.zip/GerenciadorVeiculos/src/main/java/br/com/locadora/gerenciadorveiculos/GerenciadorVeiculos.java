/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package br.com.locadora.gerenciadorveiculos;

/**
 *
 * @author lucfg
 */
public class GerenciadorVeiculos {

    public static void main(String[] args) {
        //mudar para tela principal depois
        //HomePage telaPrincipal = new HomePage();
        //telaPrincipal.setVisible(true);
    }
}
